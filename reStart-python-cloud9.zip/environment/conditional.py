userReply = input("Do you need to ship a package? (Enter yes or no) ")
userReply = input("Do you need to ship a package? (Enter yes or no) ")
else:
    print("Please come back when you need to ship a package. Thank you.")
    else:
    print("Please come back when you need to ship a package. Thank you.")