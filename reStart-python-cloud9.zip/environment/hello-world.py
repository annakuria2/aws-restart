
print("Hello, World")